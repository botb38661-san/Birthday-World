# PROGRESS - Birthday World (generic template)

## Rules (all MANDATORY)
- Creative Specification = source of truth. Build ONE stage at a time; wait for explicit approval before the next.
- Per stage: implement only that stage -> list files + purpose -> report actual tests (sandbox vs user) -> known limitations -> wait.
- Single page, no reload: scenes, detour and replay all run inside one page load.
- Mobile-first (phone portrait first), 44px+ tap targets, no hover reliance, no horizontal scroll, light animations, reduced-motion respected. Check mobile every stage.
- Modular: one module per scene; shared systems reusable; scenes talk only via sceneManager; personal content ONLY in js/config.js.
- Never invent personal details. Placeholders for names, letter, captions.

## Reuse model (APPROVED)
One generic template -> one customised copy per sister -> separate deployment each.
NO profiles, NO ?for=name, NO combined data. Code updates never overwrite config.js or assets/.
Hosting note: an obscure URL is NOT access control; anyone with the link can view everything.

## Approved decisions
- After fake fault: return to Fairy World, then transition to Memory Forest.
- Synthesized backup sounds when audio files are missing (Web Audio).
- Memory Forest is NEVER skipped: full atmosphere + gentle empty-state message when no photos.
- Dev skip button: NOT approved - keep out.
- Each scene is built only after the brother gives its full visual description.

## Architecture notes (Stage 1)
- Plain <script> tags, shared namespace `window.BW`; `CONFIG` is a global const from js/config.js.
- Load order: config.js -> sceneManager.js -> bro.js -> effects.js -> app.js.
- Scene object hooks: init(root, api), start(), end(), pause(), resume(), reset() (all optional).
- sceneManager API: init, register, start, goTo, next, detour, endDetour, restart, on('change'|'restart'|'finished'), current, has, names, isDetour. Moves are queued, never overlap.
- end() must stop timers/audio but not wipe DOM; restart() wipes scene DOM and re-inits fresh.
- bro API: say(text, delayMs) [delayMs = wait BEFORE the typing indicator], sayQueue([...]), dismiss(), clear(). Bubble tap dismisses.
- Console shortcuts: sceneManager, bro, effects.
- Scene files (scene0.js ...) and their <script> tags are added by their own stages.

## Stages
- [x] 1  Skeleton and engine - BUILT, sandbox-tested; awaiting user phone/desktop check and approval
- [x] 2A Scene 0 Mysterious Entrance - BUILT, sandbox-tested; awaiting user device review and approval
- [ ] 2B Candle scene (needs the brother's full visual description first)
- [ ] 2C Cake, blow (mic + button), song, confetti
- [ ] 3  Cup game
- [ ] 4  Fairy Garden
- [ ] 5  Fake fault and pig
- [ ] 6  Memory Forest
- [ ] 7  Star Lake
- [ ] 8  Letter
- [ ] 9  Best-bro challenge
- [ ] 10 Second birthday + secret ending + replay
- [ ] 11 Polish and testing

## Stage 2A notes (Scene 0)
- New: js/audio.js (central audio manager), js/scene0.js. Changed: index.html, css/style.css, css/animations.css, js/config.js, js/app.js. Unchanged: sceneManager.js, bro.js, effects.js.
- Stage 1 test message removed (app.js and config).
- Approved decisions implemented: silent entrance until first tap; synth chime + soft pad on tap; mute button (top-right, appears after first sound, mute persists across replay); lavender bloom -> dissolve to near-black -> sceneManager.next(); no tap-to-skip; opening bro message 1.2s after button; landscape two columns; only the button is interactive.
- Scene 0 ends on a near-black screen (class s0-done, layers hidden, animations stopped). With no next scene registered, next() returns false and fires 'finished' (no error). Register the candle scene after 'scene0' in app.js and it takes over.
- audio API: init(btn), unlock() [call inside a tap], playSfx('portal'), startAmbient({src,fadeMs,level,fileVolume}), stopAmbient(ms), stopAll(ms), setMuted/toggleMute/isMuted. One ambient at a time; sfx never stack; failures never block the story. app.js fades audio out on restart.
- config.js now holds: opening.lines, opening.buttonLabel, audio.ambient (optional file; empty = synthesized), brotherMessages.opening.
- Scene 0 CSS is scoped to .scene0 / .s0-* (end of style.css). Shared keyframes: drift, twinkle, breathe, spin-slow, glow-pulse, haze-move.

## Known limitations (Stage 2A)
- Tested in Chromium only (Safari/iPhone, Firefox, real touch hardware, real speakers untested).
- Entrance is silent on first visit (browser rule). iPhone silent switch may mute web audio.
- If audio.ambient points to a missing file, the browser logs a harmless 404 and the synth pad plays instead.
- Sound quality/volume of the synthesized chime and pad needs a human ear.
