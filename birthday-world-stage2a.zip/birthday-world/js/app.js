/* app.js - startup. Connects the pieces and registers the scenes.
   Personal content is NOT here; it is in js/config.js. */
(function () {
  'use strict';

  function startApp() {
    const stageEl = document.getElementById('stage');
    const barEl = document.getElementById('bro-bar');
    if (!stageEl || !barEl) { console.error('[app] #stage or #bro-bar missing from index.html'); return; }
    if (typeof CONFIG === 'undefined') { console.error('[app] js/config.js did not load.'); return; }

    BW.sceneManager.init(stageEl);
    BW.bro.init(barEl);
    BW.audio.init(document.getElementById('mute-btn'));

    // When the adventure restarts: clear brother messages and fade out all sound.
    BW.sceneManager.on('restart', function () { BW.bro.clear(); BW.audio.stopAll(400); });

    // Short names for typing in the browser console (and for the plan's examples).
    window.sceneManager = BW.sceneManager;
    window.bro = BW.bro;
    window.effects = BW.effects;
    window.audio = BW.audio;

    // Scenes are registered here in story order.
    BW.sceneManager.register('scene0', BW.scene0);      // Mysterious Entrance
    // Next: the candle scene is registered here when it is built.

    BW.sceneManager.start();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startApp);
  else startApp();
})();
