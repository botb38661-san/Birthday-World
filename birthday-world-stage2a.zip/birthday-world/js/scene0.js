/* scene0.js - SCENE 0: The Mysterious Entrance (between worlds).
   A dark space, a glowing portal, two story lines, then one magical button.
   Tapping the button opens the portal, fades to near-black and calls sceneManager.next().
   All text comes from CONFIG (js/config.js). This file holds behaviour only. */
(function () {
  'use strict';
  window.BW = window.BW || {};

  // timing in milliseconds (shorter when the visitor prefers reduced motion)
  const TIMING = {
    normal:  { portal: 500, firstLine: 1000, lineGap: 2000, buttonAfter: 1600, broAfterButton: 1200, dark: 1500, finish: 2400 },
    reduced: { portal: 100, firstLine: 300,  lineGap: 800,  buttonAfter: 700,  broAfterButton: 1200, dark: 300,  finish: 1300 }
  };

  let root = null, refs = {}, timers = [], entered = false, handedOff = false;

  function rand(a, b) { return a + Math.random() * (b - a); }
  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function make(tag, cls, parent) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (parent) parent.appendChild(e);
    return e;
  }
  function later(fn, ms) {
    const id = setTimeout(function () { timers = timers.filter(function (t) { return t !== id; }); fn(); }, ms);
    timers.push(id);
  }
  function clearTimers() { timers.forEach(clearTimeout); timers = []; }
  function cfg() { return (typeof CONFIG !== 'undefined' && CONFIG.opening) ? CONFIG.opening : {}; }

  /* ---------- building the scene ---------- */
  function buildParticles(layer) {
    const count = Math.min(window.innerWidth, window.innerHeight) < 600 ? 22 : 34;
    const colours = ['#ffffff', '#d9ccff', '#ffc6e2', '#ffe3a8'];
    const frag = document.createDocumentFragment();
    for (let i = 0; i < count; i++) {
      const p = document.createElement('i');
      p.className = 's0-p';
      const big = Math.random() < 0.12;
      const s = big ? rand(4.5, 6) : rand(2, 3.8);
      const set = function (k, v) { p.style.setProperty(k, v); };
      set('--x', rand(2, 98).toFixed(1) + '%');
      set('--y', rand(5, 95).toFixed(1) + '%');
      set('--s', s.toFixed(1) + 'px');
      set('--c', pick(colours));
      set('--d', rand(12, 26).toFixed(1) + 's');
      set('--dl', '-' + rand(0, 26).toFixed(1) + 's');
      set('--tw', rand(2.5, 6).toFixed(1) + 's');
      set('--rise', rand(15, 30).toFixed(0) + 'vh');
      set('--sway', rand(-14, 14).toFixed(0) + 'px');
      set('--hi', (big ? 0.95 : rand(0.45, 0.85)).toFixed(2));
      frag.appendChild(p);
    }
    layer.appendChild(frag);
  }

  function setLabel(node, text) {           // the ✨ in the label twinkles on its own
    node.textContent = '';
    String(text).split('✨').forEach(function (part, i) {
      if (i > 0) make('span', 's0-spark', node).textContent = '✨';
      if (part) node.appendChild(document.createTextNode(part));
    });
  }

  function init(r) {
    root = r; refs = {}; entered = false; handedOff = false;
    root.classList.add('scene0');

    const bg = make('div', 's0-bg', root);
    make('div', 's0-haze s0-haze-a', bg);
    make('div', 's0-haze s0-haze-b', bg);

    refs.particles = make('div', 's0-particles', root);
    refs.particles.setAttribute('aria-hidden', 'true');
    buildParticles(refs.particles);

    const layout = make('div', 's0-layout', root);

    refs.portalWrap = make('div', 's0-portal-wrap', layout);
    refs.portalWrap.setAttribute('aria-hidden', 'true');
    make('div', 's0-halo', refs.portalWrap);
    const portal = make('div', 's0-portal', refs.portalWrap);
    const voidEl = make('div', 's0-void', portal);
    make('div', 's0-swirl', voidEl);
    make('div', 's0-rim', portal);
    [20, 75, 140, 200, 255, 320].forEach(function (deg, i) {
      const sp = make('i', 's0-sp', refs.portalWrap);
      const a = deg * Math.PI / 180;
      sp.style.left = (50 + 50 * Math.cos(a)).toFixed(1) + '%';
      sp.style.top = (50 + 50 * Math.sin(a)).toFixed(1) + '%';
      sp.style.setProperty('--tw', (2.2 + i * 0.7).toFixed(1) + 's');
      sp.style.setProperty('--dl', '-' + (i * 0.9).toFixed(1) + 's');
    });

    const copy = make('div', 's0-copy', layout);
    refs.lines = (cfg().lines || []).map(function (text) {
      const p = make('p', 's0-line', copy);
      p.textContent = text;
      return p;
    });
    refs.btn = make('button', 's0-btn', copy);
    refs.btn.type = 'button';
    make('span', 's0-btn-glow', refs.btn);
    make('span', 's0-btn-ring', refs.btn);
    setLabel(make('span', 's0-btn-label', refs.btn), cfg().buttonLabel || 'ENTER ✨');
    refs.btn.addEventListener('click', onEnter);

    refs.bloom = make('div', 's0-bloom', root);
    refs.bloom.setAttribute('aria-hidden', 'true');
    refs.veil = make('div', 's0-veil', root);
    refs.veil.setAttribute('aria-hidden', 'true');
  }

  /* ---------- the intro sequence ---------- */
  function start() {
    const t = BW.prefersReducedMotion() ? TIMING.reduced : TIMING.normal;
    later(function () { refs.portalWrap.classList.add('on'); }, t.portal);

    let at = t.firstLine;
    refs.lines.forEach(function (line, i) {
      later(function () {
        if (i > 0) refs.lines[i - 1].classList.add('dim');
        line.classList.add('on');
      }, at);
      at += t.lineGap;
    });
    const buttonAt = (refs.lines.length ? at - t.lineGap + t.buttonAfter : t.firstLine);
    later(function () {
      refs.btn.classList.add('on');
      const msg = CONFIG.brotherMessages && CONFIG.brotherMessages.opening;
      if (msg) BW.bro.say(msg, t.broAfterButton);
    }, buttonAt);

    // Replay: sound is already allowed, so the very soft ambience can begin with the entrance.
    if (BW.audio.isUnlocked()) BW.audio.startAmbient({ src: ambientSrc(), fadeMs: 3000, level: 0.03, fileVolume: 0.2 });
  }

  function ambientSrc() { return (CONFIG.audio && CONFIG.audio.ambient) || ''; }

  /* ---------- tapping the button ---------- */
  function onEnter() {
    if (entered) return;
    entered = true;
    refs.btn.setAttribute('aria-disabled', 'true');
    const reduced = BW.prefersReducedMotion();
    const t = reduced ? TIMING.reduced : TIMING.normal;

    // Sound: the tap unlocks audio. Any audio problem is ignored; the story continues.
    try {
      if (BW.audio.unlock()) {
        BW.audio.playSfx('portal');
        BW.audio.startAmbient({ src: ambientSrc(), fadeMs: 2000 });
      }
    } catch (e) { /* silent */ }

    BW.bro.clear();

    if (reduced) {
      root.classList.add('s0-rm');
    } else {
      // measure the portal so the light and the particles grow from / fall toward its centre
      const r = refs.portalWrap.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const size = r.height;
      refs.bloom.style.width = refs.bloom.style.height = size + 'px';
      refs.bloom.style.left = (cx - size / 2) + 'px';
      refs.bloom.style.top = (cy - size / 2) + 'px';
      refs.bloom.style.setProperty('--s0-bs', (Math.hypot(window.innerWidth, window.innerHeight) / (0.5 * size)).toFixed(2));
      refs.particles.style.transformOrigin = cx + 'px ' + cy + 'px';
    }
    root.classList.add('s0-go');

    later(function () { root.classList.add('s0-dark'); }, t.dark);   // light dissolves to near-black
    later(finish, t.finish);
  }

  function finish() {
    root.classList.add('s0-done');          // everything hidden and animations stop: a near-black screen
    if (handedOff) return;
    handedOff = true;
    // Hand-off to the next scene. If none is registered yet, next() simply returns false
    // and the screen stays near-black; when the candle scene is registered it takes over.
    try { BW.sceneManager.next(); } catch (e) { console.warn('[scene0] hand-off:', e); }
  }

  function end() { clearTimers(); }
  function reset() { clearTimers(); BW.bro.clear(); entered = false; handedOff = false; root = null; refs = {}; }

  BW.scene0 = { init: init, start: start, end: end, reset: reset };
})();
