/* effects.js - shared visual effects. Stage 1: empty placeholders so scenes can already call them.
   Each one is filled in by the stage that first needs it. */
(function () {
  'use strict';
  window.BW = window.BW || {};

  BW.effects = {
    confetti: function (options) { /* Stage 2 */ },
    petals:   function (options) { /* Stage 4 */ },
    stars:    function (options) { /* Stage 7 */ },
    glitch:   function (options) { /* Stage 5 */ },
    shake:    function (options) { /* Stage 5 */ }
  };
})();
