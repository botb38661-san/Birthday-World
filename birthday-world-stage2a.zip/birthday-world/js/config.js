/* config.js - ALL personal content for this one sister lives here and nowhere else.
   Shared code (scenes, effects, CSS) never contains personal text.
   Replace the placeholders for each customised copy. Never put another sister's content here. */

const CONFIG = {
  sisterName: "SISTER_NAME",
  brotherName: "BROTHER_NAME",

  opening: {
    lines: [
      "Somewhere, in a little world beyond imagination...",
      "A special celebration is waiting for someone."
    ],
    buttonLabel: "ENTER THE FAIRY WORLD ✨"
  },

  audio: {
    ambient: ""                     // optional: e.g. "assets/music/ambient.mp3". Empty = soft synthesized ambience
  },

  birthday: {
    cakeName: "SISTER_NAME",
    song: "assets/music/birthday.mp3"
  },

  compliments: {
    fairyLines: [],                 // Stage 4
    gameSuccess: []                 // Stage 3
  },

  monkey: {
    dialogues: [],                  // Stages 3 and 5
    pigImage: "assets/images/pig.jpg"
  },

  photos: [
    // Stage 6. Example: { src: "assets/images/photo1.jpg", caption: "PERSONAL_CAPTION" }
  ],

  letter: {
    paragraphs: []                  // Stage 8 (about 100-150 words in total)
  },

  brotherMessages: {
    opening: "Okay, let's see what happens..."
  },

  ending: {
    birthdayWish: "",               // Stage 10
    secretMessage: []               // Stage 10
  }
};
