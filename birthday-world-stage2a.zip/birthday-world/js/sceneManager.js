/* sceneManager.js - the "director". Only one scene is visible at a time.
   Scenes are registered in story order. Each scene is an object with optional hooks:
     init(root, api)  - build the scene's DOM inside `root` (called once, lazily)
     start()          - scene becomes visible
     end()            - scene is leaving: stop timers/audio (do not wipe the DOM)
     pause()/resume() - used only for detours (the scene stays intact while hidden)
     reset()          - called on restart, before the scene's DOM is wiped
   A scene finishes by calling BW.sceneManager.next(). Everything runs in ONE page load. */
(function () {
  'use strict';
  window.BW = window.BW || {};

  const FADE_MS = 600;
  const entries = new Map();      // name -> { name, mod, root, state, initialised }
  const order = [];               // story order
  const detourStack = [];         // scenes waiting to be resumed after a detour
  const listeners = {};
  let stageEl = null;
  let currentName = null;
  let chain = Promise.resolve();  // all moves run one after another, never overlapping

  const reduceQuery = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  function prefersReducedMotion() { return !!(reduceQuery && reduceQuery.matches); }

  function on(evt, fn) { (listeners[evt] = listeners[evt] || []).push(fn); }
  function emit(evt, data) {
    (listeners[evt] || []).forEach(function (fn) {
      try { fn(data); } catch (e) { console.error('[sceneManager] listener error:', e); }
    });
  }

  // Run a scene hook; a crashing scene must never break the story.
  function call(entry, hook, args) {
    const fn = entry.mod[hook];
    if (typeof fn !== 'function') return;
    try { fn.apply(entry.mod, args || []); }
    catch (e) { console.error('[scene "' + entry.name + '"] ' + hook + '() failed:', e); }
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function enqueue(task) {
    chain = chain.then(task).catch(function (e) { console.error('[sceneManager]', e); return false; });
    return chain;
  }

  function init(el) {
    stageEl = el;
    stageEl.style.setProperty('--scene-ms', FADE_MS + 'ms');
  }

  function register(name, mod) {
    if (typeof name !== 'string' || !name || !mod || typeof mod !== 'object') {
      console.warn('[sceneManager] register(name, sceneObject) needs a name and an object.');
      return false;
    }
    if (entries.has(name)) { console.warn('[sceneManager] scene already registered:', name); return false; }
    entries.set(name, { name: name, mod: mod, root: null, state: 'idle', initialised: false });
    order.push(name);
    return true;
  }

  function ensureInit(entry) {
    if (!entry.root) {
      entry.root = document.createElement('section');
      entry.root.className = 'scene';
      entry.root.dataset.scene = entry.name;
      entry.root.setAttribute('aria-hidden', 'true');
      stageEl.appendChild(entry.root);
    }
    if (!entry.initialised) {
      entry.initialised = true;
      call(entry, 'init', [entry.root, api]);
    }
  }

  async function doGo(name, opts) {
    const next = entries.get(name);
    if (!next || !stageEl) { console.warn('[sceneManager] cannot go to scene:', name); return false; }
    const prev = currentName ? entries.get(currentName) : null;
    if (prev === next && !opts.force) return false;

    const ms = prefersReducedMotion() ? 0 : (typeof opts.durationMs === 'number' ? opts.durationMs : FADE_MS);
    stageEl.style.setProperty('--scene-ms', ms + 'ms');
    stageEl.dataset.transition = opts.transition || 'fade';

    if (prev) {
      if (opts.pause) { prev.state = 'paused'; call(prev, 'pause'); }
      else if (prev.state === 'active') { prev.state = 'ended'; call(prev, 'end'); }
      prev.root.classList.remove('active');
      prev.root.setAttribute('aria-hidden', 'true');
    }

    ensureInit(next);
    const resuming = next.state === 'paused';
    currentName = name;
    next.state = 'active';
    next.root.classList.add('active');
    next.root.removeAttribute('aria-hidden');
    call(next, resuming ? 'resume' : 'start');
    emit('change', { from: prev ? prev.name : null, to: name });

    if (ms > 0) await sleep(ms);
    return true;
  }

  function goTo(name, opts) { opts = opts || {}; return enqueue(function () { return doGo(name, opts); }); }

  function next(opts) {
    opts = opts || {};
    return enqueue(function () {
      const i = currentName ? order.indexOf(currentName) : -1;
      const target = order[i + 1];
      if (!target) { emit('finished'); return false; }
      return doGo(target, opts);
    });
  }

  // Temporary detour: the current scene is paused (kept intact), then endDetour() brings it back.
  function detour(name, opts) {
    opts = opts || {};
    return enqueue(function () {
      if (!currentName || !entries.has(name)) { console.warn('[sceneManager] cannot detour to:', name); return false; }
      detourStack.push(currentName);
      return doGo(name, Object.assign({}, opts, { pause: true }));
    });
  }
  function endDetour(opts) {
    opts = opts || {};
    return enqueue(function () {
      const origin = detourStack.pop();
      if (!origin) { console.warn('[sceneManager] endDetour() called with no detour active.'); return false; }
      return doGo(origin, opts);
    });
  }

  // Full reset inside the same page: end scenes, wipe their DOM, go back to the first scene.
  function restart(opts) {
    opts = opts || {};
    return enqueue(function () {
      entries.forEach(function (e) {
        if (e.state === 'active' || e.state === 'paused') call(e, 'end');
        if (e.initialised) {
          call(e, 'reset');
          e.root.className = 'scene';
          e.root.removeAttribute('style');
          e.root.setAttribute('aria-hidden', 'true');
          e.root.textContent = '';
          e.initialised = false;
        }
        e.state = 'idle';
      });
      detourStack.length = 0;
      currentName = null;
      emit('restart');
      return order.length ? doGo(order[0], opts) : false;
    });
  }

  function start() { return enqueue(function () { return order.length ? doGo(order[0], {}) : false; }); }

  const api = {
    init: init, register: register, on: on, start: start,
    goTo: goTo, next: next, detour: detour, endDetour: endDetour, restart: restart,
    current: function () { return currentName; },
    has: function (n) { return entries.has(n); },
    names: function () { return order.slice(); },
    isDetour: function () { return detourStack.length > 0; }
  };

  BW.sceneManager = api;
  BW.prefersReducedMotion = prefersReducedMotion;
})();
