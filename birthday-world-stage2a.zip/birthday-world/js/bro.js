/* bro.js - the brother message bubble (independent of every scene).
   say(text, delayMs)   - wait delayMs, show a typing "..." for 1 second, show the text, auto-hide.
   sayQueue([...])      - several messages, one after another. Items: "text" or { text, delayMs }.
   dismiss()            - hide the current message early (also happens when the bubble is tapped).
   clear()              - drop everything queued and hide now (used on scene change / restart).
   Both say() and sayQueue() return a Promise that resolves when the message(s) are gone. */
(function () {
  'use strict';
  window.BW = window.BW || {};

  const TYPING_MS = 1000;
  const HIDE_MS = 350;
  const MIN_READ_MS = 2600;
  const MS_PER_CHAR = 55;
  const EXTRA_READ_MS = 1000;

  let bubbleEl = null, textEl = null;
  const queue = [];
  let running = false;
  let cur = null;
  let wake = null;                // lets dismiss()/clear() cut a wait short

  function init(barEl) {
    bubbleEl = barEl.querySelector('#bro-bubble');
    textEl = barEl.querySelector('#bro-text');
    if (bubbleEl) bubbleEl.addEventListener('click', dismiss);
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function interruptible(ms) {
    return new Promise(function (resolve) {
      if (!cur || cur.dismissed) { resolve(); return; }
      const t = setTimeout(done, ms);
      function done() { clearTimeout(t); if (wake === done) wake = null; resolve(); }
      wake = done;
    });
  }
  function readMs(text) { return Math.max(MIN_READ_MS, text.length * MS_PER_CHAR + EXTRA_READ_MS); }

  async function run(item) {
    cur = item;
    if (item.delayMs) await interruptible(item.delayMs);
    if (!item.dismissed) {
      textEl.textContent = '';
      bubbleEl.classList.add('show', 'typing');
      await interruptible(TYPING_MS);
    }
    if (!item.dismissed) {
      textEl.textContent = item.text;
      bubbleEl.classList.remove('typing');
      await interruptible(readMs(item.text));
    }
    bubbleEl.classList.remove('show', 'typing');
    await sleep(HIDE_MS);
    cur = null;
  }

  async function pump() {
    if (running) return;
    running = true;
    while (queue.length) {
      const item = queue.shift();
      try { await run(item); } catch (e) { console.error('[bro]', e); cur = null; }
      item.resolve();
    }
    running = false;
  }

  function say(text, delayMs) {
    return new Promise(function (resolve) {
      if (!bubbleEl || typeof text !== 'string' || !text.trim()) {
        if (!bubbleEl) console.warn('[bro] message bar not found.');
        resolve(); return;
      }
      queue.push({ text: text, delayMs: Math.max(0, Number(delayMs) || 0), resolve: resolve, dismissed: false });
      pump();
    });
  }

  function sayQueue(items) {
    if (!Array.isArray(items)) { console.warn('[bro] sayQueue() needs an array.'); return Promise.resolve(); }
    return Promise.all(items.map(function (it) {
      return typeof it === 'string' ? say(it) : say(it && it.text, it && it.delayMs);
    }));
  }

  function dismiss() {
    if (!cur) return;
    cur.dismissed = true;
    if (wake) wake();
  }

  function clear() {
    while (queue.length) queue.shift().resolve();
    dismiss();
  }

  BW.bro = { init: init, say: say, sayQueue: sayQueue, dismiss: dismiss, clear: clear };
})();
