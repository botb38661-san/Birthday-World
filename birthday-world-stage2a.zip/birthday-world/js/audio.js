/* audio.js - the one central audio manager (shared by all scenes).
   - Sound can only start after a tap: call BW.audio.unlock() inside a click handler.
   - Only ONE ambient track at a time; a new one replaces the old one. A sound effect replaces
     an earlier copy of itself, so nothing stacks.
   - One master volume handles mute for everything. Mute stays on across replay.
   - Every call is wrapped in try/catch: audio problems never stop the story.
   - If an ambient file is given but missing, a soft synthesized pad plays instead. */
(function () {
  'use strict';
  window.BW = window.BW || {};

  const MASTER_LEVEL = 0.9;
  let ctx = null, master = null;
  let unlocked = false, muted = false;
  let btnEl = null;
  let ambient = null;                   // the single active ambient handle
  const sfxActive = new Map();          // sound effect name -> handle
  let chain = Promise.resolve();        // ambient start/stop run one after another

  function queue(fn) {
    chain = chain.then(fn).catch(function (e) { console.warn('[audio]', e); return false; });
    return chain;
  }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  /* ---------- mute button ---------- */
  function updateButton() {
    if (!btnEl) return;
    btnEl.textContent = muted ? '🔇' : '🔊';
    const label = muted ? 'Unmute sound' : 'Mute sound';
    btnEl.setAttribute('aria-label', label);
    btnEl.title = label;
  }
  function init(el) {
    btnEl = el;
    if (!btnEl) return;
    btnEl.addEventListener('click', toggleMute);
    updateButton();
  }

  /* ---------- unlock (must be called from a tap/click) ---------- */
  function unlock() {
    try {
      if (!ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return false;
        ctx = new AC();
        master = ctx.createGain();
        master.gain.value = muted ? 0 : MASTER_LEVEL;
        master.connect(ctx.destination);
      }
      if (ctx.state === 'suspended') { const p = ctx.resume(); if (p && p.catch) p.catch(function () {}); }
      // iPhone trick: play one silent sample inside the tap so later sounds are allowed
      const s = ctx.createBufferSource();
      s.buffer = ctx.createBuffer(1, 1, 22050);
      s.connect(ctx.destination);
      s.start(0);
      unlocked = true;
      if (btnEl) btnEl.hidden = false;
      return true;
    } catch (e) {
      console.warn('[audio] could not start audio:', e);
      return false;
    }
  }
  function isUnlocked() { return unlocked && !!ctx; }
  function ensureRunning() {
    if (ctx && ctx.state === 'suspended') { const p = ctx.resume(); if (p && p.catch) p.catch(function () {}); }
  }

  /* ---------- mute (one place, applies to everything) ---------- */
  function setMuted(m) {
    muted = !!m;
    try {
      if (master) {
        master.gain.cancelScheduledValues(ctx.currentTime);
        master.gain.setTargetAtTime(muted ? 0 : MASTER_LEVEL, ctx.currentTime, 0.03);
      }
      if (ambient && ambient.applyMute) ambient.applyMute();
    } catch (e) { console.warn('[audio]', e); }
    updateButton();
  }
  function toggleMute() { setMuted(!muted); }
  function isMuted() { return muted; }

  /* ---------- synthesized sound effects ---------- */
  const SFX = {
    // soft rising shimmer: four gentle notes with an echo
    portal: function () {
      const t0 = ctx.currentTime;
      const out = ctx.createGain();
      const dly = ctx.createDelay(1); dly.delayTime.value = 0.24;
      const fb = ctx.createGain(); fb.gain.value = 0.33;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2800;
      out.connect(master); out.connect(dly); dly.connect(lp); lp.connect(fb); fb.connect(dly); lp.connect(master);
      const nodes = [out, dly, fb, lp];
      [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) {
        const o = ctx.createOscillator(); o.type = i % 2 ? 'triangle' : 'sine'; o.frequency.value = f;
        const g = ctx.createGain(); const st = t0 + i * 0.17;
        g.gain.setValueAtTime(0, st);
        g.gain.linearRampToValueAtTime(0.09, st + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0008, st + 1.0);
        o.connect(g); g.connect(out); o.start(st); o.stop(st + 1.1);
        nodes.push(g);
      });
      return makeSfxHandle('portal', out, nodes, 0.17 * 3 + 1.1 + 1.8);
    }
  };

  function makeSfxHandle(name, out, nodes, lifeSec) {
    let done = false;
    const handle = {
      stop: function (fadeSec) {
        try { const n = ctx.currentTime; out.gain.cancelScheduledValues(n); out.gain.setTargetAtTime(0, n, (fadeSec || 0.05) / 3); } catch (e) {}
        setTimeout(cleanup, ((fadeSec || 0.05) + 0.1) * 1000);
      }
    };
    function cleanup() {
      if (done) return; done = true;
      nodes.forEach(function (n) { try { n.disconnect(); } catch (e) {} });
      if (sfxActive.get(name) === handle) sfxActive.delete(name);
    }
    setTimeout(cleanup, lifeSec * 1000 + 100);
    return handle;
  }

  function playSfx(name) {
    try {
      if (!isUnlocked() || !SFX[name]) return false;
      ensureRunning();
      const prev = sfxActive.get(name);
      if (prev) prev.stop(0.05);
      sfxActive.set(name, SFX[name]());
      return true;
    } catch (e) { console.warn('[audio] sound effect failed:', e); return false; }
  }

  /* ---------- ambient: synthesized pad, or an optional file ---------- */
  function makePad(fadeMs, level) {
    const t0 = ctx.currentTime;
    const out = ctx.createGain();
    out.gain.setValueAtTime(0, t0);
    out.gain.linearRampToValueAtTime(level, t0 + fadeMs / 1000);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; lp.Q.value = 0.3;
    lp.connect(out); out.connect(master);
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.09;      // very slow breathing
    const lfoG = ctx.createGain(); lfoG.gain.value = level * 0.25;
    lfo.connect(lfoG); lfoG.connect(out.gain); lfo.start(t0);
    const oscs = [lfo], nodes = [out, lp, lfoG];
    [[174.61, 3], [261.63, -4], [329.63, 5], [392.0, -3]].forEach(function (n) {
      const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = n[0]; o.detune.value = n[1];
      const g = ctx.createGain(); g.gain.value = 0.25;
      o.connect(g); g.connect(lp); o.start(t0);
      oscs.push(o); nodes.push(g);
    });
    return {
      key: 'pad',
      applyMute: function () {},                 // master gain already handles mute
      stop: function (fadeMs) {
        const f = Math.max(0.02, (fadeMs || 0) / 1000);
        try { const n = ctx.currentTime; out.gain.cancelScheduledValues(n); out.gain.setValueAtTime(out.gain.value, n); out.gain.linearRampToValueAtTime(0, n + f); } catch (e) {}
        return sleep(f * 1000 + 60).then(function () {
          oscs.forEach(function (o) { try { o.stop(); } catch (e) {} });
          oscs.concat(nodes).forEach(function (n) { try { n.disconnect(); } catch (e) {} });
        });
      }
    };
  }

  function fadeElement(el, target, ms) {
    if (el._fade) clearInterval(el._fade);
    return new Promise(function (resolve) {
      const start = el.volume, steps = Math.max(1, Math.round(ms / 50)); let i = 0;
      el._fade = setInterval(function () {
        i++; el.volume = Math.max(0, Math.min(1, start + (target - start) * (i / steps)));
        if (i >= steps) { clearInterval(el._fade); el._fade = null; resolve(); }
      }, 50);
    });
  }

  function makeFile(src, fadeMs, volume) {
    return new Promise(function (resolve) {
      let settled = false;
      const el = new Audio();
      function fail() {
        if (settled) return; settled = true;
        try { el.pause(); el.removeAttribute('src'); el.load(); } catch (e) {}
        resolve(null);
      }
      el.loop = true; el.volume = 0; el.muted = muted; el.src = src;
      el.addEventListener('error', fail, { once: true });
      const p = el.play();
      if (!p || !p.then) { fail(); return; }
      p.then(function () {
        if (settled) return; settled = true;
        fadeElement(el, volume, fadeMs);
        resolve({
          key: src,
          applyMute: function () { el.muted = muted; },
          stop: function (ms) {
            return fadeElement(el, 0, Math.max(20, ms || 0)).then(function () {
              try { el.pause(); el.removeAttribute('src'); el.load(); } catch (e) {}
            });
          }
        });
      }).catch(fail);
    });
  }

  function stopAmbientNow(fadeMs) {
    const a = ambient; ambient = null;
    return a ? a.stop(fadeMs) : Promise.resolve();
  }

  // opts: { src, fadeMs, level (pad), fileVolume (file) }
  function startAmbient(opts) {
    opts = opts || {};
    return queue(async function () {
      if (!isUnlocked()) return false;
      ensureRunning();
      const src = opts.src || '';
      const key = src || 'pad';
      if (ambient && ambient.key === key) return true;          // already playing: never stack
      await stopAmbientNow(250);
      const fadeMs = typeof opts.fadeMs === 'number' ? opts.fadeMs : 2000;
      let handle = null;
      if (src) handle = await makeFile(src, fadeMs, typeof opts.fileVolume === 'number' ? opts.fileVolume : 0.4);
      if (!handle) handle = makePad(fadeMs, typeof opts.level === 'number' ? opts.level : 0.05);
      ambient = handle;
      return true;
    });
  }
  function stopAmbient(fadeMs) {
    return queue(function () { return stopAmbientNow(typeof fadeMs === 'number' ? fadeMs : 800); });
  }
  function stopAll(fadeMs) {
    const f = typeof fadeMs === 'number' ? fadeMs : 500;
    return queue(async function () {
      sfxActive.forEach(function (h) { h.stop(f / 1000); });
      await stopAmbientNow(f);
    });
  }

  BW.audio = {
    init: init, unlock: unlock, isUnlocked: isUnlocked,
    playSfx: playSfx, startAmbient: startAmbient, stopAmbient: stopAmbient, stopAll: stopAll,
    setMuted: setMuted, toggleMute: toggleMute, isMuted: isMuted
  };
})();
